<?php
/**
 * 全局常量配置
 * @author Hollis
 */

//数据库配置
defined('DB_HOST') or define('DB_HOST', '192.168.6.245');
defined('DB_PORT') or define('DB_PORT', '3306');
defined('DB_NAME') or define('DB_NAME', 'jnx');
defined('DB_USER') or define('DB_USER', 'jnx');
defined('DB_PASS') or define('DB_PASS', 'jnx');


//redis配置
defined('REDIS_HOST') or define('REDIS_HOST', 'xss242');
defined('REDIS_PORT') or define('REDIS_PORT', '16380');
defined('REDIS_PWD') or define('REDIS_PWD', '6ai2xL7ky97hUAzXmDtTcyiQibUpNgKj');
defined('REDIS_DB') or define('REDIS_DB', 1);