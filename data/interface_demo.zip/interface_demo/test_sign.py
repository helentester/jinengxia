#coding=utf-8
import requests
import threading
import time

'''
xxx嘉宾签到系统，接口并发测试
'''

# 签到基本url
base_url = 'http://guest.xxxx.com/event'

# user1
headers_a = {'User-Agent': 'Mozilla/5.0',
'Cookie': 'cur_event=21; XXXXSESSIONID=16792116222094E2B2E3F304821439C691DFCAC6666F47',
'Authorization': 'Basic bWVpenU6bWVpenUyMDE0'} 

# test1
headers_b = {'User-Agent': 'Mozilla/5.0',
'Cookie': 'cur_event=21; XXXXSESSIONID=167921162591074497612A0A68E9A4A01D11F6AD6A06EF',
'Authorization': 'Basic bWVpenU6bWVpenUyMDE0'}

# test2
headers_c = {'User-Agent': 'Mozilla/5.0',
'Cookie': 'cur_event=21; XXXXSESSIONID=167921162735975A3784357C0EA598238DDF198735C69D',
'Authorization': 'Basic bWVpenU6bWVpenUyMDE0'}

auths=('user', 'user2014')


def thread_user1():
    for i in range(666):
        phone = 13823610001 + i
        datas = {'eventid':'21','param':'phone','value':str(phone)}
        r1 = requests.post(base_url+'/check_signin', headers = headers_a,data=datas,auth=auths)  
        a = r1.json()
        gid = a['result']['gid']

        datas2 = {'gid':gid}
        r = requests.post(base_url+'/check_signin_by_hand', headers = headers_a,data=datas2,auth=auths)
        print "thread1"  
        print r.text


def thread_user2():
    for i in range(666,1332):
        phone = 13823610001 + i
        datas = {'eventid':'21','param':'phone','value':str(phone)}
        r = requests.post(base_url+'/check_signin', headers = headers_b,data=datas,auth=auths)  
        a = r.json()
        gid = a['result']['gid']

        datas2 = {'gid':gid}
        r = requests.post(base_url+'/check_signin_by_hand', headers = headers_b,data=datas2,auth=auths)  
        print "thread2"
        print r.text


def thread_user3():
    for i in range(1332,2000):
        phone = 13823610001 + i
        datas = {'eventid':'21','param':'phone','value':str(phone)}
        r = requests.post(base_url+'/check_signin', headers = headers_c,data=datas,auth=auths)  
        a = r.json()
        gid = a['result']['gid']

        datas2 = {'gid':gid}
        r = requests.post(base_url+'/check_signin_by_hand', headers = headers_c,data=datas2,auth=auths)  
        print "thread3"
        print r.text



#创建线程数组
threads = []

#创建线程t1
t1 = threading.Thread(target=thread_user1,args=())
threads.append(t1)

#创建线程t2
t2 = threading.Thread(target=thread_user2,args=())
threads.append(t2)

#创建线程t3
t3 = threading.Thread(target=thread_user3,args=())
threads.append(t3)


if __name__ == '__main__':
    now = time.strftime("%Y-%m-%d %H_%M_%S")
    print 'start Sign: %s' %now 
    #启动线程
    for i in threads:
        i.start()
    #守护线程
    for i in threads:
        i.join()
    now = time.strftime("%Y-%m-%d %H_%M_%S")
    print 'all end: %s' %now

