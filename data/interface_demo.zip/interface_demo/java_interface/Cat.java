package mypor.interfaces.demo;
import mypor.interfaces.demo.IAnimal;

//类：猫
public class Cat implements IAnimal{

	public String Behavior()
	{
		String ActiveTime = "我白天睡觉,晚上捉老鼠。";
		
		return ActiveTime;
	}
}