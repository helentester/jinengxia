
__author__ = 'huzhiheng'


import sys
sys.path.append('../db_fixture')
from mysql_setting import MySQLOperating


# Inster table datas
def inster_data(table,datas):
    db = MySQLOperating()
    db.clear(table)
    for data in datas:
        db.insert(table,data)
    db.close()


# Create data
table_poll_question = "polls_question"
datas_poll_question =[{'id':1,'question_text':'you buy pro6?'}
]

table_poll_choice = "polls_choice"
datas_poll_choice =[{'id':1,'choice_text':'buy','votes':0,'question_id':1},
                    {'id':2,'choice_text':'not buy','votes':0,'question_id':1},
]


# init data
def init_data():
    inster_data(table_poll_question,datas_poll_question)
    inster_data(table_poll_choice,datas_poll_choice)


if __name__ == '__main__':
    init_data()
