package mypor.interfaces.demo;
import mypor.interfaces.demo.Dog;
import mypor.interfaces.demo.Cat;


public class Test {
	
	public static void main(String[] args) {         
        //调用dog和cat的行为 
		Dog d = new Dog();
		Cat c = new Cat();
        System.out.println(d.Behavior());
        System.out.println(c.Behavior());
    }
}