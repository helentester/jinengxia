#coding=utf-8
import requests
import unittest
import json
import hashlib
import time
from ReportTestRunner import HTMLTestRunner


class edmMailSystemTest(unittest.TestCase):

    def setUp(self):
        self.base_url = "http://edm.xxxx.com/mail/send"
        self.now_time = int(time.time())

    def md5_str(self,now_time):
        # $app_key.$time.$app_ secret.'&edm-meizu'
        app_key = 'EhzFi'
        time_ = str(now_time)
        app_secret = 'qx44pnKgm9u9V3YZAG8u'
        md5 = hashlib.md5()
        md5.update(app_key + time_ + app_secret + '&edm-xxxx')
        md5_ = md5.hexdigest()
        return md5_

    def test_all_parameter_null(self):
        u'''测试不传任何参数'''
        r = requests.post(self.base_url)
        code = r.status_code
        dicts = json.loads(r.text)
        print(dicts)
        self.assertEqual(code,200)
        self.assertEqual(dicts['status'],10021)
        self.assertEqual(dicts['message'],'Parameters  error!')

    def test_all_parameter_incomplete(self):
        u'''测试参数不完整'''
        payload = {'subject':'send mail test','html':'hello, xiaoming.',}
        r = requests.post(self.base_url,data=payload)
        code = r.status_code
        dicts = json.loads(r.text)
        print(dicts)
        self.assertEqual(code,200)
        self.assertEqual(dicts['status'],10021)
        self.assertEqual(dicts['message'],'Parameters  error!')

    def test_app_null(self):
        u'''这个程序不存在'''
        now_time = str(self.now_time)
        sign = self.md5_str(self.now_time)
        payload = {'subject':'send mail test',
                   'html':'hello, xiaoming.',
                   'app_key':'GhzDi_app_null',  
                   'time':now_time,
                   'sign':sign,
                   'to':'huzhiheng@meizu.com'}
        r = requests.post(self.base_url,data=payload)
        code = r.status_code
        dicts = json.loads(r.text)
        print(dicts)
        self.assertEqual(code,200)
        self.assertEqual(dicts['status'],10022)
        self.assertEqual(dicts['message'],'The app is not Exist!')

    def test_timeout(self):
        u'''时间过期'''
        now_time = str(self.now_time-61)
        sign = self.md5_str(self.now_time)
        payload = {'subject':'send mail test',
                   'html':'hello, xiaoming.',
                   'app_key':'GhzDi',
                   'time':now_time,
                   'sign':sign,
                   'to':'huzhiheng@meizu.com'}
        r = requests.post(self.base_url,data=payload)
        code = r.status_code
        dicts = json.loads(r.text)
        print(dicts)
        self.assertEqual(code,200)
        self.assertEqual(dicts['status'],10027)
        self.assertEqual(dicts['message'],'The time is  expire!')

    def test_sign_error(self):
        u'''签名错误'''
        now_time = str(self.now_time)
        sign = self.md5_str(self.now_time)
        payload = {'subject':'send mail test',
                   'html':'hello, xiaoming.',
                   'app_key':'GhzDi',  
                   'time':now_time,
                   'sign':sign+'aaaa',
                   'to':'huzhiheng@meizu.com'}
        r = requests.post(self.base_url,data=payload)
        code = r.status_code
        dicts = json.loads(r.text)
        print(dicts)
        self.assertEqual(code,200)
        self.assertEqual(dicts['status'],10028)
        self.assertEqual(dicts['message'],'The sign is not match!')

    def test_to_mail_exceed_1000(self):
        u'''单次收件人超出1000'''
        f = open("mail_list.txt",'r')
        to_mail = f.read()
        f.close()
        now_time = str(self.now_time)
        sign = self.md5_str(self.now_time)
        payload = {'subject':'send mail test',
                   'html':'hello, xiaoming.',
                   'app_key':'GhzDi',
                   'time':now_time,
                   'sign':sign,
                   'to':to_mail}
        r = requests.post(self.base_url,data=payload)
        code = r.status_code
        dicts = json.loads(r.text)
        print(dicts)
        self.assertEqual(code,200)
        self.assertEqual(dicts['status'],10030)
        self.assertEqual(dicts['message'],'Too many receivers!')

    def test_send_mail_success(self):
        u'''发送成功'''
        now_time = str(self.now_time)
        sign = self.md5_str(self.now_time)
        payload = {'subject':'send mail test',
                   'html':'hello, xiaoming.',
                   'app_key':'GhzDi',
                   'time':now_time,
                   'sign':sign,
                   'to':'16309483@qq.com'}
        #print(json.dumps(payload))
        r = requests.post(self.base_url,data=payload)
        code = r.status_code
        dicts = json.loads(r.text)
        print(dicts)
        self.assertEqual(code,200)
        self.assertEqual(dicts['status'],200)
        self.assertEqual(dicts['message'],'send success!')


if __name__ == '__main__':
    #unittest.main()
    
    testunit=unittest.TestSuite()
    testunit.addTest(edmMailSystemTest("test_all_parameter_null"))
    testunit.addTest(edmMailSystemTest("test_all_parameter_incomplete"))
    testunit.addTest(edmMailSystemTest("test_app_null"))
    testunit.addTest(edmMailSystemTest("test_timeout"))
    testunit.addTest(edmMailSystemTest("test_sign_error"))
    testunit.addTest(edmMailSystemTest("test_to_mail_exceed_1000"))
    testunit.addTest(edmMailSystemTest("test_send_mail_success"))

    fp = open('./result.html', 'wb')
    runner = HTMLTestRunner(stream=fp,
                            title=u'edm邮件系统接口测试',
                            description=u'用例执行情况：')
    runner.run(testunit)
    fp.close()
    