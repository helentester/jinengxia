package mypor.interfaces.demo;
import mypor.interfaces.demo.IAnimal;

//类: 狗
public class Dog implements IAnimal{
	
	public String Behavior()
	{
		String ActiveTime = "我晚上睡觉,白天活动";
		
		return ActiveTime;
	}
}