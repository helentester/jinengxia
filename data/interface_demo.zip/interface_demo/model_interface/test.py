from module import Calculator
import unittest


class TestModule(unittest.TestCase):

    def setUp(self):
        pass
    
    def tearDown(self):
        pass
    
    def test_add(self):
        c = Calculator(2, 3)
        self.assertEqual(c.add(), 5)

    def test_sub(self):
        c = Calculator(5, 3)
        self.assertEqual(c.sub(), 2)

    def test_mul(self):
        c = Calculator(2, 3)
        self.assertEqual(c.mul(), 6)

    def test_div(self):
        c = Calculator(6, 3)
        self.assertEqual(c.div(), 2)


if __name__ == '__main__':
    unittest.main()