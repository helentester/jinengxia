package mypor.interfaces.demo;

public interface IAnimal {

	public String Behavior(); //行为方法，描述各种动物的特性
}